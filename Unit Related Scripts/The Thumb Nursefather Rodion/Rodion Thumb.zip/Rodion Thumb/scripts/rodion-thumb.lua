-- rodion 10916 id

local mangSkills = { 1091606, 1091607 }
local canMang = {}

local CHAIN_SKILL = 1091605
local evadedThisAttack = false

on(TIMING.ON_BATTLE_START, function(e)
    if e.unit.id == 10916 then
        e.unit:setMangEnabled(false)
    end
end)

-- mang behaviour and visibility

for _, skillId in ipairs(mangSkills) do
    on(TIMING.ON_START_BEHAVIOUR, { skillId = skillId }, function(e)
        local id = e.unit.instanceId
        canMang[id] = (e.unit.sp >= 0)
        e.unit:setMangEnabled(canMang[id])
    end)

    contribute(DECISION.SKILL_POWER, { skillId = skillId }, function(e)
        if canMang[e.unit.instanceId] then
            return e.powerBonus + 4
        end
    end)

    on(TIMING.ON_END_ATTACK, { skillId = skillId }, function(e)
        local id = e.unit.instanceId
        if canMang[id] then
            e.unit:takeSp(10)
            e.unit:setMangEnabled(e.unit.sp >= 0)
        end
        canMang[id] = nil
    end)

    on(TIMING.ON_END_BEHAVIOUR, { skillId = skillId }, function(e)
        canMang[e.unit.instanceId] = nil
    end)
end

-- chain counter unlimited

on(TIMING.ON_SUCCESS_EVADE, { scope = "any" }, function(e)
    if not e.unit or e.unit.id ~= 10916 then return end
    evadedThisAttack = true
end)

on(TIMING.ON_END_ATTACK, { scope = "any" }, function(e)
    if not e.unit or e.unit.id == 10916 then return end

    local didEvade = evadedThisAttack
    evadedThisAttack = false

    if not didEvade then return end
    if not e.target or e.target.id ~= 10916 then return end

    e.target:useSkillNow(CHAIN_SKILL, e.unit)
end)


on(TIMING.ON_FORMATION, { scope = "any" }, function(e) -- resets after a encounter
    canMang = {}
    evadedThisAttack = false
end)