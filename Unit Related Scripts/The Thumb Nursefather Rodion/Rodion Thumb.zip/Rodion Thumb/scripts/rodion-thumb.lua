local mangSkills = {
    1091606,
    1091607
}

local canMang = {}

on(TIMING.ON_BATTLE_START, function(e)
    if e.unit.id == 10916 then
        e.unit:setMangEnabled(false)
    end
end)


for _, skillId in ipairs(mangSkills) do

    -- check sp 
    on(TIMING.ON_START_BEHAVIOUR, {skillId = skillId}, function(e)
        local id = e.unit.instanceId

        canMang[id] = (e.unit.sp >= 0)
        e.unit:setMangEnabled(canMang[id])
    end)

    -- +4 base power
    contribute(DECISION.SKILL_POWER, {skillId = skillId}, function(e)
        if canMang[e.unit.instanceId] then
            return e.powerBonus + 4
        end
    end)

    -- -10 sp at attack end
    on(TIMING.ON_END_ATTACK, {skillId = skillId}, function(e)
        local id = e.unit.instanceId

        if canMang[id] then
            e.unit:takeSp(10)
            e.unit:setMangEnabled(e.unit.sp >= 10)
        end

        canMang[id] = nil
    end)

    on(TIMING.ON_END_BEHAVIOUR, {skillId = skillId}, function(e)
        canMang[e.unit.instanceId] = nil
    end)
end

on(TIMING.ON_SUCCESS_EVADE, function(e) -- unlimited counters
    if e.unit.id ~= 10916 then return end

    e.unit:useSkillNow(1091605)
end)
