local mangSkills = {
    1091606,
    1091607
}

local canMang = {}


on(TIMING.ON_BATTLE_START, function(e) -- enables mang
    if e.unit.id == 10916 then
        e.unit:setMangEnabled(true)
    end
end)

	for _, skillId in ipairs(mangSkills) do

    on(TIMING.ON_START_BEHAVIOUR, {skillId = skillId}, function(e) -- sp check
        canMang[e.unit.instanceId] = (e.unit.sp >= 0)
    end)

    contribute(DECISION.SKILL_POWER, {skillId = skillId}, function(e) -- base power + 4
        if canMang[e.unit.instanceId] then
            return e.powerBonus + 4
        end
    end)


    on(TIMING.ON_END_ATTACK, {skillId = skillId}, function(e) -- sp cost
        if canMang[e.unit.instanceId] then
            e.unit:takeSp(10)
        end

        canMang[e.unit.instanceId] = nil
    end)

    on(TIMING.ON_END_BEHAVIOUR, {skillId = skillId}, function(e)
        canMang[e.unit.instanceId] = nil
    end)
end

on(TIMING.ON_SUCCESS_EVADE, function(e) -- skill chaining
    if e.unit.id ~= 10916 then return end
    e.unit:useSkillNow(1091605)
end)
