local coindb = import("coindb")

local WATCH = {
    "Sinking", "Laceration", "Vibration", "Burst", "Combustion",
    "Agility", "Protection", "Paralysis", "Charge", "Poise",
}

local TARGET_ID = nil
local warnedNoTarget = false

local logged, snapSelf, snapVic, ctxSelf, ctxVic = {}, {}, {}, {}, {}

local function nameOf(id)      return coindb.units[id] or ("unit" .. tostring(id)) end
local function slotStr(v)      return v and tostring(v) or "-" end

local function catOf(k)
    if k == "skill" then return "attack" end
    if k == "ego"   then return "ego" end
    if k == "guard" or k == "evade" or k == "counter" then return "defence" end
    return "other"
end

local function fmtSkill(ctx)
    local k = ctx.kind or "?"
    return string.format("skill=%d slot=%s cat=%s type=%s",
        ctx.skillId, slotStr(ctx.slot), catOf(k), k)
end

local function snapUnit(u)
    if not u then return nil end
    local s = {}
    for i = 1, #WATCH do s[WATCH[i]] = u:buffStacks(WATCH[i]) or 0 end
    return s
end

local function diffStacks(before, after)
    if not before or not after then return nil end
    local out = {}
    for i = 1, #WATCH do
        local n = WATCH[i]
        local d = (after[n] or 0) - (before[n] or 0)
        if d > 0 then out[#out + 1] = n .. "+" .. d end
    end
    return #out > 0 and table.concat(out, ",") or nil
end

local function appearanceOf(u)
    if not u then return "?" end
    local ok, a = pcall(function() return u:appearance() end)
    return ok and tostring(a) or "?"
end

local function logOnce(key, line)
    if logged[key] then return end
    logged[key] = true
    log("###D " .. line)
end

-- =============================================================
on(TIMING.ON_FORMATION, { scope = "any" }, function(e)
    logged, snapSelf, snapVic, ctxSelf, ctxVic = {}, {}, {}, {}, {}
    warnedNoTarget, TARGET_ID = false, nil

    if e.party then
        local best, bestOrder = nil, math.huge
        for _, m in ipairs(e.party) do
            if m.deployed and (m.order or math.huge) < bestOrder then
                best, bestOrder = m, m.order or math.huge
            end
        end
        if best then TARGET_ID = best.id end
    end

    if TARGET_ID then
        log(string.format("###D ---- formation: target identity=%d (%s) (deployed #1) ----",
            TARGET_ID, nameOf(TARGET_ID)))
    else
        log("###D ---- formation: no deployed target found; nothing will log ----")
    end
end)

on(TIMING.ON_BATTLE_START, { scope = "any" }, function(_)
    if TARGET_ID == nil and not warnedNoTarget then
        warnedNoTarget = true
        log("###D WARNING: no target resolved — nothing will be logged")
    end
end)

on(TIMING.ON_START_BEHAVIOUR, { scope = "any" }, function(e)
    if not TARGET_ID or not e.unit or e.unit.id ~= TARGET_ID then return end
    local uid = e.unit.instanceId
    snapSelf[uid] = snapUnit(e.unit)
    snapVic = {}
    if e.skill then
        ctxSelf[uid] = {
            skillId = e.skill.id,
            slot    = e.skill.slot,
            kind    = e.skill.kind or "skill",
            coin    = -1,
        }
    else
        ctxSelf[uid] = nil
    end
end)

on(TIMING.BEFORE_GIVE_ATTACK, { scope = "any" }, function(e)
    if not TARGET_ID then return end
    local a, v, s, c = e.attacker, e.victim, e.skill, e.coin
    if not a or not v or not s or not c then return end
    if a.id ~= TARGET_ID then return end
    if e.damage == nil then return end

    local aNew, vNew = snapUnit(a), snapUnit(v)

    -- (1) the unit gained something itself
    local ctxA, aOld = ctxSelf[a.instanceId], snapSelf[a.instanceId]
    if ctxA and aOld then
        local d = diffStacks(aOld, aNew)
        if d then
            logOnce(string.format("S|%d|%d|%d", a.id, ctxA.skillId, ctxA.coin),
                string.format("SELF     name=%s unit=%d app=%s %s coin=%d gains=%s",
                    nameOf(a.id), a.id, appearanceOf(a), fmtSkill(ctxA), ctxA.coin, d))
        end
    end

    -- (2) the unit inflicted something on the target
    local ctxV, vOld = ctxVic[v.instanceId], snapVic[v.instanceId]
    if ctxV and vOld then
        local d = diffStacks(vOld, vNew)
        if d then
            logOnce(string.format("I|%d|%d|%d", a.id, ctxV.skillId, ctxV.coin),
                string.format(
                    "INFLICT  name=%s unit=%d app=%s -> victim=%d vName=%s vApp=%s %s coin=%d infliction=%s",
                    nameOf(a.id), a.id, appearanceOf(a),
                    v.id, nameOf(v.id), appearanceOf(v),
                    fmtSkill(ctxV), ctxV.coin, d))
        end
    end

    snapSelf[a.instanceId] = aNew
    snapVic[v.instanceId]  = vNew
    ctxSelf[a.instanceId]  = { skillId = s.id, slot = s.slot,
                               kind = s.kind or "skill", coin = c.index }
    ctxVic[v.instanceId]   = { skillId = s.id, slot = s.slot,
                               kind = s.kind or "skill", coin = c.index }
end)

local function flushSelf(u)
    if not u then return end
    local uid = u.instanceId
    local cur = snapUnit(u)
    if not cur then return end
    local ctx = ctxSelf[uid]
    if ctx and snapSelf[uid] then
        local d = diffStacks(snapSelf[uid], cur)
        if d then
            logOnce(string.format("S|%d|%d|%d", u.id, ctx.skillId, ctx.coin),
                string.format("SELF     name=%s unit=%d app=%s %s coin=%d gains=%s",
                    nameOf(u.id), u.id, appearanceOf(u), fmtSkill(ctx), ctx.coin, d))
        end
    end
    snapSelf[uid] = cur
end

on(TIMING.ON_END_ATTACK, { scope = "any" }, function(e)
    if not TARGET_ID or not e.unit or e.unit.id ~= TARGET_ID then return end
    flushSelf(e.unit)
end)

on(TIMING.ON_END_TURN, { scope = "any" }, function(e)
    if not TARGET_ID or not e.unit or e.unit.id ~= TARGET_ID then return end
    flushSelf(e.unit)
end)